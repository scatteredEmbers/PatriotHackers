
public class Game{
  //we need a counter to keep track of the points
  private int click = 0;
  private int clicksPerSec = 0;
  
  private int salesforcePrice = 10;
  private int codepathPrice = 50;
  private int arcfieldPrice = 100;
  private int peratonPrice = 500;
  private int awsPrice = 1000;

  private int salesforceCount, codepathCount, arcfieldCount, peratonCount, awsCount;
  //make it a private variable so it can't be accessed by the outside

  public int getClick(){return click;}
  public void setClick(int val){click = val;}//i guess for testing purposes?

  //call this method every time someone clicks on the cookie
  public void incCount(){click++;}

  public int getClicksPerSec(){return clicksPerSec;}
  public void setClicksPerSec(int val){clicksPerSec = val;}

  //get the prices of each sponsor
  public int getSalesForcePrice(){return salesforcePrice;}
  public int getCodepathPrice(){return codepathPrice;}
  public int getArcfieldPrice(){return arcfieldPrice;}
  public int getPeratonPrice(){return peratonPrice;}
  public int getAwsPrice(){return awsPrice;}

  //get the count for each sponsor
  public int getSalesForceCount(){return salesforceCount;}
  public int getCodepathCount(){return codepathCount;}
  public int getArcfieldCount(){return arcfieldCount;}
  public int getPeratonCount(){return peratonCount;}
  public int getAwsCount(){return awsCount;}
  
  //a sponsor is purchased
  public boolean purchaseSponsor(Sponsor sponsor){
    //check if the player has enough clicks to purchase the sponsor
    //if they have enough, clicksPerSec should increase
    //the cost should be deducted from click
    //the price of the sponser increases
    switch(sponsor){
      case SALESFORCE:
        if(click >= salesforcePrice){
          clicksPerSec += 1;
          click -= salesforcePrice;
          salesforcePrice *= 1.1;
          salesforceCount++;
          if(salesforceCount > 5){
            return true;
          }
          else{
            return false;
          }
        }
        break;
      case CODEPATH:
        if(click >= codepathPrice){
          clicksPerSec += 5;
          click -= codepathPrice;
          codepathPrice *= 1.2;
          codepathCount++;
          if(codepathCount > 5){
            return true;
          }
          else{
            return false;
          }
        }
        break;
      case ARCFIELD:
        if(click >= arcfieldPrice){
          clicksPerSec += 10;
          click -= arcfieldPrice;
          arcfieldPrice *= 1.2;
          arcfieldCount++;
          if(arcfieldCount > 5){
            return true;
          }
          else{
            return false;
          }
        }
        break;
      case PERATON:
        if(click >= peratonPrice){
          clicksPerSec += 50;
          click -= peratonPrice;
          peratonPrice *= 1.5;
          peratonCount++;
          if(peratonCount > 5){
            return true;
          }
          else{
            return false;
          }
        }
        break;
      case AWS:
        if(click >= awsPrice){
          clicksPerSec += 100;
          click -= awsPrice;
          awsPrice *= 1.5;
          awsCount++;
          if(awsCount > 5){
            return true;
          }
          else{
            return false;
          }
        }
        break;
    }
    return true;
  }
}