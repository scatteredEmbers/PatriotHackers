import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.Timer;
import java.awt.Image;
import javax.swing.ImageIcon;

public class Main {
    private static void GUI(Game game) {
      JFrame frame = new JFrame();
      frame.setLayout(new BorderLayout());
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.setBackground(new Color(203,139,232));
      JPanel centerColumn = new JPanel();
      centerColumn.setBackground(new Color(203,139,232));
      centerColumn.setLayout(new GridBagLayout());
      GridBagConstraints gbc = new GridBagConstraints();
      gbc.gridwidth = GridBagConstraints.REMAINDER;
      gbc.fill = GridBagConstraints.HORIZONTAL;
      JPanel sponsors = new JPanel();
      sponsors.setLayout(new GridBagLayout());
      sponsors.setBackground(new Color(203,139,232));
      JPanel sponsorGallery = new JPanel();
      sponsorGallery.setBackground(new Color(203,139,232));
      sponsorGallery.setLayout(new GridBagLayout());
      JPanel salesForcePanel = new JPanel();
      salesForcePanel.setBackground(new Color(203,139,232));
      JPanel codePathPanel = new JPanel();
      codePathPanel.setBackground(new Color(203,139,232));
      JPanel arcfieldPanel = new JPanel();
      arcfieldPanel.setBackground(new Color(203,139,232));
      JPanel peratonPanel = new JPanel();
      peratonPanel.setBackground(new Color(203,139,232));
      JPanel awsPanel = new JPanel();
      awsPanel.setBackground(new Color(203,139,232));
      JPanel salesForceGallery = new JPanel();
      salesForceGallery.setBackground(new Color(203,139,232));
      JPanel codePathGallery = new JPanel();
      codePathGallery.setBackground(new Color(203,139,232));
      JPanel arcfieldGallery = new JPanel();
      arcfieldGallery.setBackground(new Color(203,139,232));
      JPanel peratonGallery = new JPanel();
      peratonGallery.setBackground(new Color(203,139,232));
      JPanel awsGallery = new JPanel();
      awsGallery.setBackground(new Color(203,139,232));
      JLabel titleLabel, numHacksLabel, cpsLabel, salesForcePriceLabel, codePathPriceLabel, arcfieldPriceLabel, peratonPriceLabel, awsPriceLabel, salesForceCountLabel, codePathCountLabel, arcfieldCountLabel, peratonCountLabel, awsCountLabel, sponsorGalleryLabel;
      JButton patriotButton, salesForceButton, codePathButton, arcfieldButton, peratonButton, awsButton;
      numHacksLabel = new JLabel("0", SwingConstants.CENTER);
      cpsLabel = new JLabel("0 hacks per second", SwingConstants.CENTER);
      Icon patriotIcon = new ImageIcon("patriotIcon.png"); 
      patriotButton = new JButton(patriotIcon);
      patriotButton.setOpaque(false);
      patriotButton.setContentAreaFilled(false);
      patriotButton.setBorderPainted(false);
      patriotButton.setPreferredSize(new Dimension(300, 200));
      patriotButton.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){
          game.incCount();
          numHacksLabel.setText("" + game.getClick());
        }
      });

      titleLabel = new JLabel("Patriot Hacker", SwingConstants.CENTER); 

      //defining sponsor icons
      Icon salesForceIcon = new ImageIcon("salesforceIcon.png");
      Icon codePathIcon = new ImageIcon("codepathIcon.png");
      Icon arcfieldIcon = new ImageIcon("arcfieldIcon.png");
      Icon peratonIcon = new ImageIcon("peratonIcon.png");
      Icon awsIcon = new ImageIcon("awsIcon.png");
      
      salesForcePriceLabel = new JLabel (game.getSalesForcePrice() + " hacks");
      codePathPriceLabel = new JLabel (game.getCodepathPrice() + " hacks");
      arcfieldPriceLabel = new JLabel (game.getArcfieldPrice() + " hacks");
      peratonPriceLabel = new JLabel (game.getPeratonPrice() + " hacks");
      awsPriceLabel = new JLabel (game.getAwsPrice() + " hacks");

      salesForceCountLabel = new JLabel("Sales Force bought: " + game.getSalesForceCount());
      codePathCountLabel = new JLabel("Code Path bought: " + game.getCodepathCount());
      arcfieldCountLabel = new JLabel("Arcfield bought: " + game.getArcfieldCount());
      peratonCountLabel = new JLabel("Peraton bought: " + game.getPeratonCount());
      awsCountLabel = new JLabel("aws bought: " + game.getAwsCount());

      //defines properties for sales force sponsor
      Icon salesForceBackground = new ImageIcon("salesForceBackground.png");
      salesForceButton = new JButton("Sales Force", salesForceIcon);
      salesForceButton.setOpaque(false);
      salesForceButton.setContentAreaFilled(false);
      salesForceButton.setBorderPainted(false);
      
      salesForceButton.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          if (!game.purchaseSponsor(Sponsor.SALESFORCE)) {
            JLabel salesForceIconLabel = new JLabel(salesForceBackground);
            salesForceGallery.add(salesForceIconLabel);
          }
          salesForceCountLabel.setText("Sales Force Bought: " + game.getSalesForceCount());
          numHacksLabel.setText("" + game.getClick());
          cpsLabel.setText(game.getClicksPerSec() + " hacks per second");
          salesForcePriceLabel.setText(game.getSalesForcePrice()  + " hacks");
        }
      });

      //defines properties for code path sponsor
      Icon codePathBackground = new ImageIcon("codePathBackground.png");
      codePathButton = new JButton("Code Path", codePathIcon);
      codePathButton.setOpaque(false);
      codePathButton.setContentAreaFilled(false);
      codePathButton.setBorderPainted(false);
      
      codePathButton.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){
          if(!game.purchaseSponsor(Sponsor.CODEPATH)){
            JLabel codePathIconLabel = new JLabel(codePathBackground);
            codePathGallery.add(codePathIconLabel);
          }
          codePathCountLabel.setText("Codepath Bought: " + game.getCodepathCount());
          numHacksLabel.setText("" + game.getClick());
          cpsLabel.setText(game.getClicksPerSec() + " hacks per second");
          codePathPriceLabel.setText(game.getCodepathPrice()  + " hacks");
        }
      });

      //defines properties for arcfield sponsor
      Icon arcfieldBackground = new ImageIcon("arcfieldBackground.png");
      arcfieldButton = new JButton("Arcfield", arcfieldIcon);
      arcfieldButton.setOpaque(false);
      arcfieldButton.setContentAreaFilled(false);
      arcfieldButton.setBorderPainted(false);
      
      arcfieldButton.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){
          if(!game.purchaseSponsor(Sponsor.ARCFIELD)){
            JLabel arcfieldIconLabel = new JLabel(arcfieldBackground);
            arcfieldGallery.add(arcfieldIconLabel);
            }
          arcfieldCountLabel.setText("Arcfield Bought: " + game.getArcfieldCount());
          numHacksLabel.setText("" + game.getClick());
          cpsLabel.setText(game.getClicksPerSec() + " hacks per second");
          arcfieldPriceLabel.setText(game.getArcfieldPrice()  + " hacks");
        }
      });

      //defines properties for peraton sponsor
      Icon peratonBackground = new ImageIcon("peratonBackground.png");
      peratonButton = new JButton("Peraton", peratonIcon);
      peratonButton.setOpaque(false);
      peratonButton.setContentAreaFilled(false);
      peratonButton.setBorderPainted(false);
      
      peratonButton.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){
          if(!game.purchaseSponsor(Sponsor.PERATON)){
            JLabel peratonIconLabel = new JLabel(peratonBackground);
            peratonGallery.add(peratonIconLabel);
          }
          
          //if(!game.purchaseSponsor(Sponsor.PERATON)){
            //JLabel peratonIconLabel = new JLabel(arcfieldBackground);
            //peratonGallery.add(peratonIconLabel);
          //}
          peratonCountLabel.setText("Peraton Bought: " + game.getPeratonCount());
          numHacksLabel.setText("" + game.getClick());
          cpsLabel.setText(game.getClicksPerSec() + " hacks per second");
          peratonPriceLabel.setText(game.getPeratonPrice()  + " hacks");
        }
      });

      //defines properties for aws sponsor
      Icon awsBackground = new ImageIcon("awsBackground.png");
      awsButton = new JButton("aws", awsIcon);
      awsButton.setOpaque(false);
      awsButton.setContentAreaFilled(false);
      awsButton.setBorderPainted(false);
      
      awsButton.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){
          if(!game.purchaseSponsor(Sponsor.AWS)){
            JLabel awsIconLabel = new JLabel(awsBackground);
            awsGallery.add(awsIconLabel);
          }
          awsCountLabel.setText("aws Bought: " + game.getAwsCount());
          numHacksLabel.setText("" + game.getClick());
          cpsLabel.setText(game.getClicksPerSec() + " hacks per second");
          awsPriceLabel.setText(game.getAwsPrice()  + " hacks");
        }
      });

      Timer timer = new Timer(1000, new ActionListener(){
        public void actionPerformed(ActionEvent e){
          game.setClick(game.getClick() + game.getClicksPerSec());
          numHacksLabel.setText("" + game.getClick());
        }
      });
      timer.start();

      salesForceGallery.add(salesForceCountLabel);
      codePathGallery.add(codePathCountLabel);
      arcfieldGallery.add(arcfieldCountLabel);
      peratonGallery.add(peratonCountLabel);
      awsGallery.add(awsCountLabel);

      sponsorGalleryLabel = new JLabel("Sponsor Gallery", SwingConstants.CENTER);

      sponsorGallery.add(sponsorGalleryLabel, gbc);
      sponsorGallery.add(salesForceGallery, gbc);
      sponsorGallery.add(codePathGallery, gbc);
      sponsorGallery.add(arcfieldGallery, gbc);
      sponsorGallery.add(peratonGallery, gbc);
      sponsorGallery.add(awsGallery, gbc);

      salesForcePanel.add(salesForceButton);
      salesForcePanel.add(salesForcePriceLabel);

      codePathPanel.add(codePathButton);
      codePathPanel.add(codePathPriceLabel);

      arcfieldPanel.add(arcfieldButton);
      arcfieldPanel.add(arcfieldPriceLabel);

      peratonPanel.add(peratonButton);
      peratonPanel.add(peratonPriceLabel);

      awsPanel.add(awsButton);
      awsPanel.add(awsPriceLabel);
      
      sponsors.add(salesForcePanel, gbc);
      sponsors.add(codePathPanel, gbc);
      sponsors.add(arcfieldPanel, gbc);
      sponsors.add(peratonPanel, gbc);
      sponsors.add(awsPanel, gbc);

      centerColumn.add(numHacksLabel, gbc);
      centerColumn.add(cpsLabel, gbc);
      centerColumn.add(patriotButton, gbc);

      frame.add(titleLabel, BorderLayout.PAGE_START);
      frame.add(sponsors, BorderLayout.LINE_END);
      frame.add(centerColumn, BorderLayout.CENTER);
      frame.add(sponsorGallery, BorderLayout.LINE_START);

      frame.setSize(1000, 500);
      frame.setVisible(true);
      
    }
    
  public static void main(String[] args) {
    Game game = new Game();
    GUI(game);
  }
}
