import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.Timer;
import java.awt.Image;
import javax.swing.ImageIcon;

public class Main {
    private static void GUI(Game game) {
      JFrame frame = new JFrame();
      frame.setLayout(new BorderLayout());
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.setBackground(new Color(203,139,232));
      JPanel centerColumn = new JPanel();
      centerColumn.setBackground(new Color(203,139,232));
      centerColumn.setLayout(new GridBagLayout());
      GridBagConstraints gbc = new GridBagConstraints();
      gbc.gridwidth = GridBagConstraints.REMAINDER;
      gbc.fill = GridBagConstraints.HORIZONTAL;
      JPanel sponsors = new JPanel();
      sponsors.setLayout(new GridBagLayout());
      sponsors.setBackground(new Color(203,139,232));
      JPanel sponsorGallery = new JPanel();
      sponsorGallery.setBackground(new Color(203,139,232));
      sponsorGallery.setLayout(new BoxLayout(sponsorGallery, BoxLayout.Y_AXIS));
      JPanel salesForcePanel = new JPanel();
      salesForcePanel.setBackground(new Color(203,139,232));
      JPanel codePathPanel = new JPanel();
      codePathPanel.setBackground(new Color(203,139,232));
      JPanel arcfieldPanel = new JPanel();
      arcfieldPanel.setBackground(new Color(203,139,232));
      JPanel peratonPanel = new JPanel();
      peratonPanel.setBackground(new Color(203,139,232));
      JPanel awsPanel = new JPanel();
      awsPanel.setBackground(new Color(203,139,232));
      JPanel salesForceGallery = new JPanel();
      salesForceGallery.setBackground(new Color(203,139,232));
      JPanel codePathGallery = new JPanel();
      codePathGallery.setBackground(new Color(203,139,232));
      JPanel arcfieldGallery = new JPanel();
      arcfieldGallery.setBackground(new Color(203,139,232));
      JPanel peratonGallery = new JPanel();
      peratonGallery.setBackground(new Color(203,139,232));
      JPanel awsGallery = new JPanel();
      awsGallery.setBackground(new Color(203,139,232));
      JLabel titleLabel, numHacksLabel, cpsLabel, salesForcePriceLabel, codePathPriceLabel, arcfieldPriceLabel, peratonPriceLabel, awsPriceLabel, salesForceCountLabel, codePathCountLabel, arcfieldCountLabel, peratonCountLabel, awsCountLabel, sponsorGalleryLabel;
      JButton patriotButton, salesForceButton, codePathButton, arcfieldButton, peratonButton, awsButton;
      numHacksLabel = new JLabel("0", SwingConstants.CENTER);
      cpsLabel = new JLabel("0 hacks per second", SwingConstants.CENTER);
      Icon patriotIcon = new ImageIcon("patriotIcon.png"); //insert name of file for the following
      patriotButton = new JButton(patriotIcon);
      patriotButton.setOpaque(false);
      patriotButton.setContentAreaFilled(false);
      patriotButton.setBorderPainted(false);
      patriotButton.setPreferredSize(new Dimension(100, 100));
      patriotButton.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){
          game.incCount();
          numHacksLabel.setText("" + game.getClick());
        }
      });

      titleLabel = new JLabel("Patriot Hacker");      
      Icon salesForceIcon = new ImageIcon("salesforceIcon.png");
      Icon codePathIcon = new ImageIcon("codepathIcon.png");
      Icon arcfieldIcon = new ImageIcon("arcfieldIcon.png");
      Icon peratonIcon = new ImageIcon("peretonIcon.png");
      Icon awsIcon = new ImageIcon("awsIcon.png");
      
      salesForcePriceLabel = new JLabel (game.getSalesForcePrice() + " hacks");
      codePathPriceLabel = new JLabel (game.getCodepathPrice() + " hacks");
      arcfieldPriceLabel = new JLabel (game.getArcfieldPrice() + " hacks");
      peratonPriceLabel = new JLabel (game.getPeratonPrice() + " hacks");
      awsPriceLabel = new JLabel (game.getAwsPrice() + " hacks");

      salesForceCountLabel = new JLabel("Sales Force bought: " + game.getSalesForceCount());
      codePathCountLabel = new JLabel("Code Path bought: " + game.getCodepathCount());
      arcfieldCountLabel = new JLabel("Arcfield bought: " + game.getArcfieldCount());
      peratonCountLabel = new JLabel("Peraton bought: " + game.getPeratonCount());
      awsCountLabel = new JLabel("aws bought: " + game.getAwsCount());
      
      Icon salesForceBackground = new ImageIcon("salesForceBackground.png");
      salesForceButton = new JButton("Sales Force", salesForceIcon);
      salesForceButton.setOpaque(false);
      salesForceButton.setContentAreaFilled(false);
      salesForceButton.setBorderPainted(false);
      JLabel salesForceIconLabel = new JLabel(salesForceBackground);
      salesForceButton.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){
          if(!game.purchaseSponsor(Sponsor.SALESFORCE)){ 
            salesForceGallery.add(salesForceIconLabel);
          }
          numHacksLabel.setText("" + game.getClick());
          cpsLabel.setText(game.getClicksPerSec() + " hacks per second");
          salesForcePriceLabel.setText(game.getSalesForcePrice()  + " hacks");
        }
      });
      Icon codePathBackground = new ImageIcon("codePathBackground.png");
      codePathButton = new JButton("Code Path", codePathIcon);
      codePathButton.setOpaque(false);
      codePathButton.setContentAreaFilled(false);
      codePathButton.setBorderPainted(false);
      //JLabel codePathIconLabel = new JLabel(codePathBackground);
      codePathButton.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){
          if(!game.purchaseSponsor(Sponsor.CODEPATH)){
            JLabel codePathIconLabel = new JLabel(codePathBackground);
            codePathGallery.add(codePathIconLabel);
            codePathCountLabel.setText("Codepath Bought: " + game.getCodepathCount());
          }
          numHacksLabel.setText("" + game.getClick());
          cpsLabel.setText(game.getClicksPerSec() + " hacks per second");
          codePathPriceLabel.setText(game.getCodepathPrice()  + " hacks");
        }
      });
      Icon arcfieldBackground = new ImageIcon("arcfieldBackground.png");
      arcfieldButton = new JButton("Arcfield", arcfieldIcon);
      arcfieldButton.setOpaque(false);
      arcfieldButton.setContentAreaFilled(false);
      arcfieldButton.setBorderPainted(false);
      JLabel arcfieldIconLabel = new JLabel(arcfieldBackground);
      arcfieldButton.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){
          if(!game.purchaseSponsor(Sponsor.ARCFIELD)){
            arcfieldGallery.add(arcfieldIconLabel);
          }
          numHacksLabel.setText("" + game.getClick());
          cpsLabel.setText(game.getClicksPerSec() + " hacks per second");
          arcfieldPriceLabel.setText(game.getArcfieldPrice()  + " hacks");
        }
      });
      Icon peratonBackground = new ImageIcon("peretonBackground.png");
      peratonButton = new JButton("Peraton", peratonIcon);
      peratonButton.setOpaque(false);
      peratonButton.setContentAreaFilled(false);
      peratonButton.setBorderPainted(false);
      JLabel peratonIconLabel = new JLabel(peratonBackground);
      peratonButton.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){
          if(!game.purchaseSponsor(Sponsor.PERATON)){
            peratonGallery.add(peratonIconLabel);
          }
          numHacksLabel.setText("" + game.getClick());
          cpsLabel.setText(game.getClicksPerSec() + " hacks per second");
          peratonPriceLabel.setText(game.getPeratonPrice()  + " hacks");
        }
      });
      Icon awsBackground = new ImageIcon("awsBackground.png");
      awsButton = new JButton("aws", awsIcon);
      awsButton.setOpaque(false);
      awsButton.setContentAreaFilled(false);
      awsButton.setBorderPainted(false);
      JLabel awsIconLabel = new JLabel(awsBackground);
      awsButton.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){
          if(!game.purchaseSponsor(Sponsor.AWS)){
            awsGallery.add(awsIconLabel);
          }
          numHacksLabel.setText("" + game.getClick());
          cpsLabel.setText(game.getClicksPerSec() + " hacks per second");
          awsPriceLabel.setText(game.getAwsPrice()  + " hacks");
        }
      });

      Timer timer = new Timer(1000, new ActionListener(){
        public void actionPerformed(ActionEvent e){
          game.setClick(game.getClick() + game.getClicksPerSec());
          numHacksLabel.setText("" + game.getClick());
        }
      });
      timer.start();

      salesForceGallery.add(salesForceCountLabel);
      codePathGallery.add(codePathCountLabel);
      arcfieldGallery.add(arcfieldCountLabel);
      peratonGallery.add(peratonCountLabel);
      awsGallery.add(awsCountLabel);

      sponsorGalleryLabel = new JLabel("Sponsor Gallery");

      sponsorGallery.add(sponsorGalleryLabel);
      sponsorGallery.add(salesForceGallery);
      sponsorGallery.add(codePathGallery);
      sponsorGallery.add(arcfieldGallery);
      sponsorGallery.add(peratonCountLabel);
      sponsorGallery.add(awsGallery);

      salesForcePanel.add(salesForceButton);
      salesForcePanel.add(salesForcePriceLabel);

      codePathPanel.add(codePathButton);
      codePathPanel.add(codePathPriceLabel);

      arcfieldPanel.add(arcfieldButton);
      arcfieldPanel.add(arcfieldPriceLabel);

      peratonPanel.add(peratonButton);
      peratonPanel.add(peratonPriceLabel);

      awsPanel.add(awsButton);
      awsPanel.add(awsPriceLabel);
      
      sponsors.add(salesForcePanel, gbc);
      sponsors.add(codePathPanel, gbc);
      sponsors.add(arcfieldPanel, gbc);
      sponsors.add(peratonPanel, gbc);
      sponsors.add(awsPanel, gbc);

      centerColumn.add(numHacksLabel, gbc);
      centerColumn.add(cpsLabel, gbc);
      centerColumn.add(patriotButton, gbc);

      frame.add(titleLabel, BorderLayout.PAGE_START);
      frame.add(sponsors, BorderLayout.LINE_END);
      frame.add(centerColumn, BorderLayout.CENTER);
      frame.add(sponsorGallery, BorderLayout.LINE_START);

      frame.setSize(1000, 800);
      frame.setVisible(true);
      
    }
    
  public static void main(String[] args) {
    Game game = new Game();
    GUI(game);
  }
}
